define({
  "name": "",
  "version": "1.0.0",
  "description": "",
  "header": {
    "content": "<h1>Giftcast Application</h1>\n<p>This documentation contains code for Giftcast Application.</p>\n"
  },
  "template": {
    "withCompare": true,
    "withGenerator": false
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-01-10T11:29:39.851Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
