# Giftcast Application

This documentation contains code for Giftcast Application.
