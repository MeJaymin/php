<?php
	$config['protocol'] = 'SMTP';
	$config['charset'] = 'iso-8859-1';
	$config['wordwrap'] = TRUE;
	$config['mailtype'] = 'html';
	$config['smtp_crypto'] = 'tls';
	$config['smtp_host'] = 'smtp.gmail.com';
	$config['smtp_user'] = 'zaptest9876@gmail.com';
	$config['smtp_pass'] = 'zaptest9876#';
	$config['smtp_port'] = '465';
	$config['newline'] = "\r\n"; 
?>