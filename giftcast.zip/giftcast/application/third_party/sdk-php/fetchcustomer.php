<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require 'autoload.php';
error_reporting(E_ALL);
use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;
$merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
$merchantAuthentication->setName("2xmBMWu5J6q");
$merchantAuthentication->setTransactionKey("5D5d5XS983GynKVs");

$request = new AnetAPI\CreateTransactionRequest();
$request->setMerchantAuthentication($merchantAuthentication);

$refId = 'ref' . time();
$customerProfileId = "1503139290";
$customerPaymentProfileId = "1502496494";
//request requires customerProfileId and customerPaymentProfileId
$request = new AnetAPI\GetCustomerPaymentProfileRequest();
$request->setMerchantAuthentication($merchantAuthentication);
$request->setRefId($refId);
$request->setCustomerProfileId($customerProfileId);
$request->setCustomerPaymentProfileId($customerPaymentProfileId);

$controller = new AnetController\GetCustomerPaymentProfileController($request);
$response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);
if(($response != null))
{
	if ($response->getMessages()->getResultCode() == "Ok")
	{
		echo "GetCustomerPaymentProfile SUCCESS: " . "\n";
		echo "Customer Payment Profile Id: " . $response->getPaymentProfile()->getCustomerPaymentProfileId() . "\n";
		echo "Customer Payment Profile Billing Address: " . $response->getPaymentProfile()->getbillTo()->getAddress(). "\n";
		echo "Customer Payment Profile Card Last 4 " . $response->getPaymentProfile()->getPayment()->getCreditCard()->getCardNumber(). "\n";
		echo '<pre>';
		print_r($response->getPaymentProfile());
	}
}