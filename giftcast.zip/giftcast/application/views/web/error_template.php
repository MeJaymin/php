<?php

$this->load->view($body);
 
?>