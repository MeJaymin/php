
<!DOCTYPE HTML>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Dashboard</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">

        <script src="<?php echo ASSETS_URL; ?>admin/js/jquery.js"></script>
        <script src="<?php echo ASSETS_URL; ?>admin/js/custom.js"></script>
        <script src="<?php echo ASSETS_URL; ?>admin/js/jquery.validate.min.js"></script>
        <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,300italic,400italic,600,600italic,700,700italic,800,800italic' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>admin/css/font-awesome.min.css" media="screen">
        
        <script type="text/javascript" src="<?php echo ASSETS_URL; ?>admin/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" src="<?php echo ASSETS_URL; ?>admin/js/dataTables.responsive.min.js"></script>
    

        <link rel='stylesheet' href='<?php echo ASSETS_URL; ?>admin/css/jquery.dataTables.min.css' media='screen'>
        <link rel='stylesheet' href='http://cdn.datatables.net/responsive/1.0.0/css/dataTables.responsive.css' media='screen'>
        <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>admin/css/reset.css" media="screen">
        <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>admin/css/master.css" media="screen">
        <link rel="stylesheet" href="<?php echo ASSETS_URL; ?>admin/css/responsive.css" media="screen">

    </head>
    <script type="text/javascript">
        var base_url = "<?php echo ASSETS_URL; ?>";
    </script>
        <body class="homepage">
	        <div class="wrapper">

			<div class="container">
			    <div class="loginbox">
			        <!-- <div class="logo"><img src="<?php echo ASSETS_URL; ?>/admin/images/logo.png"></div> -->
			        <div class="loginform">
						<div> <center><span class="required">This link is expired, Please try again!</span></center> </div>
			        </div>
			    </div>

			</div>
		</body>
	</html>
