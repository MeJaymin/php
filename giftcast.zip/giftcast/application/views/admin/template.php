<?php
$this->load->view('admin/common/header');
$this->load->view($body);
$this->load->view('admin/common/footer'); 
?>